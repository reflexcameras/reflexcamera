Contributors
============

All contributors (by number of commits):

- Mike Boers <github@mikeboers.com>; `@mikeboers <https://github.com/mikeboers>`_

* Jeremy Lainé <jeremy.laine@m4x.org>; `@jlaine <https://github.com/jlaine>`_

- WyattBlue <wyattblue@auto-editor.com>; `@WyattBlue <https://github.com/WyattBlue>`_
- Mark Reid <mindmark@gmail.com>; `@markreidvfx <https://github.com/markreidvfx>`_

* Vidar Tonaas Fauske <vidartf@gmail.com>; `@vidartf <https://github.com/vidartf>`_
* laggykiller <chaudominic2@gmail.com>; `@laggykiller <https://github.com/laggykiller>`_
* Billy Shambrook <billy.shambrook@gmail.com>; `@billyshambrook <https://github.com/billyshambrook>`_
* Casper van der Wel <caspervdw@gmail.com>
* Philip de Nier <philipn@rd.bbc.co.uk>
* Tadas Dailyda <tadas@dailyda.com>
* JoeUgly <41972063+JoeUgly@users.noreply.github.com>
* Justin Wong <46082645+uvjustin@users.noreply.github.com>

- Alba Mendez <me@alba.sh>
- Mark Harfouche <mark.harfouche@gmail.com>
- Xinran Xu <xxr@megvii.com>; `@xxr3376 <https://github.com/xxr3376>`_
- Dan Allan <daniel.b.allan@gmail.com>; `@danielballan <https://github.com/danielballan>`_
- Dave Johansen <davejohansen@gmail.com>
- Moonsik Park <moonsik.park@estsoft.com>
- Santtu Keskinen <santtu.keskinen@gmail.com>
- Christoph Rackwitz <christoph.rackwitz@gmail.com>
- Alireza Davoudi <davoudialireza@gmail.com>; `@adavoudi <https://github.com/adavoudi>`_
- Jonathan Drolet <jonathan.drolet@riedel.net>
- Moritz Kassner <moritzkassner@gmail.com>; `@mkassner <https://github.com/mkassner>`_
- Thomas A Caswell <tcaswell@gmail.com>; `@tacaswell <https://github.com/tacaswell>`_
- Ulrik Mikaelsson <ulrik.mikaelsson@magine.com>; `@rawler <https://github.com/rawler>`_
- Wel C. van der <wel@Physics.LeidenUniv.nl>
- Will Patera <willpatera@gmail.com>; `@willpatera <https://github.com/willpatera>`_

* rutsh <Eugene.Krokhalev@gmail.com>
* Felix Vollmer <FelixVollmer@gmail.com>
* Santiago Castro <bryant1410@gmail.com>
* Christian Clauss <cclauss@me.com>
* Ihor Liubymov <ihor.liubymov@ring.com>
* Johannes Erdfelt <johannes@erdfelt.com>
* Karl Litterfeldt <kalle.litterfeldt@gmail.com>; `@litterfeldt <https://github.com/litterfeldt>`_
* Martin Larralde <martin.larralde@ens-cachan.fr>
* Simon-Martin Schröder <martin.schroeder@nerdluecht.de>
* Matteo Destro <matteo.est@gmail.com>
* mephi42 <mephi42@gmail.com>
* Miles Kaufmann <mkfmnn@gmail.com>
* Pablo Prietz <pablo@prietz.org>
* Radek Senfeld <rush@logic.cz>; `@radek-senfeld <https://github.com/radek-senfeld>`_
* Benjamin Chrétien <2742231+bchretien@users.noreply.github.com>
* Marc Mueller <30130371+cdce8p@users.noreply.github.com>
* zzjjbb <31069326+zzjjbb@users.noreply.github.com>
* Hanz <40712686+HanzCEO@users.noreply.github.com>
* Joe Schiff <41972063+JoeSchiff@users.noreply.github.com>
* Artturin <Artturin@artturin.com>
* Ian Lee <IanLee1521@gmail.com>
* Ryan Huang <NPN@users.noreply.github.com>
* Arthur Barros <arthbarros@gmail.com>
* Carlos Ruiz <carlos.ruiz.dominguez@west.cmu.edu>
* David Plowman <david.plowman@raspberrypi.com>
* Maxime Desroches <desroches.maxime@gmail.com>
* egao1980 <egao1980@gmail.com>
* Eric Kalosa-Kenyon <ekalosak@gmail.com>
* elxy <elxy@outlook.com>
* Gemfield <gemfield@civilnet.cn>
* Jonathan Martin <homerunisgood@hotmail.com>
* Johan Jeppsson Karlin <johjep@gmail.com>
* Philipp Klaus <klaus@physik.uni-frankfurt.de>
* Mattias Wadman <mattias.wadman@gmail.com>
* Manuel Goacolou <mgoacolou@cls.fr>
* Julian Schweizer <neuneck@gmail.com>
* Ömer Sezgin Uğurlu <omer@ugurlu.org>
* Orivej Desh <orivej@gmx.fr>
* Philipp Krähenbühl <philkr@users.noreply.github.com>
* ramoncaldeira <ramoncaldeira_328@hotmail.com>
* Roland van Laar <roland@rolandvanlaar.nl>
* Santiago Castro <sacastro@umich.edu>
* Kengo Sawatsu <seattleserv0@gmail.com>
* FirefoxMetzger <sebastian@wallkoetter.net>
* hyenal <sebastien.ehrhardt@gmail.com>
* Brendan Long <self@brendanlong.com>; `@brendanlong <https://github.com/brendanlong>`_
* Семён Марьясин <simeon@maryasin.name>
* Stephen.Y <stepheny@users.noreply.github.com>
* Tom Flanagan <theknio@gmail.com>
* Tim O'Shea <tim.oshea753@gmail.com>
* Tim Ahpee <timah@blackmagicdesign.com>
* Jonas Tingeborn <tinjon@gmail.com>
* Pino Toscano <toscano.pino@tiscali.it>
* Ulrik Mikaelsson <ulrikm@spotify.com>
* Vasiliy Kotov <vasiliy.kotov@itechart-group.com>
* Koichi Akabe <vbkaisetsu@gmail.com>
* David Joy <videan42@gmail.com>
* Sviatoslav Sydorenko (Святослав Сидоренко) <webknjaz@redhat.com>
